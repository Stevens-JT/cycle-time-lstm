# Baselines — Metrics Report

## Meta
- Timestamp: 2025-10-10T16:51:50.557429Z
- Python: 3.12.3
- Platform: Linux-6.14.0-33-generic-x86_64-with-glibc2.39
- Rows used (after target dropna): 3934
- Feature count (after selection): 120
- Split strategy: **time-based (train/val/test from ETL)**
- Features Parquet: `outputs/features_spark.parquet` (hash: `c7b36e8a19be354fc2e4fda59316b14719393adf2725944a3c3ce56f3fd8fe91`)

## Validation (used for model selection)
| model   |      MAE |    RMSE |        R2 |
|:--------|---------:|--------:|----------:|
| Ridge   | 0.672452 | 2.46329 | -0.109061 |
| RF      | 0.34863  | 2.9388  | -0.578571 |
| XGB     | 0.519703 | 3.7075  | -1.51239  |

## Test (final report)
| model   |      MAE |    RMSE |        R2 |
|:--------|---------:|--------:|----------:|
| Ridge   | 0.681592 | 2.94337 | -0.104594 |
| RF      | 0.45393  | 3.69778 | -0.743394 |
| XGB     | 0.694134 | 5.07473 | -2.28351  |

## Best Model
- Name: Ridge
- Saved at: `outputs/best_baseline.joblib`
- Best Val RMSE: 2.463290
